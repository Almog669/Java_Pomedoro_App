package Java_final_pom.View;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ViewTest {

    @Test
    void frameInit() {
    }

    @Test
    void createRootPane() {
    }

    @Test
    void processWindowEvent() {
    }

    @Test
    void setDefaultCloseOperation() {
    }

    @Test
    void getDefaultCloseOperation() {
    }

    @Test
    void setTransferHandler() {
    }

    @Test
    void getTransferHandler() {
    }

    @Test
    void update() {
    }

    @Test
    void setJMenuBar() {
    }

    @Test
    void getJMenuBar() {
    }

    @Test
    void isRootPaneCheckingEnabled() {
    }
}