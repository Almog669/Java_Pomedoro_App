package Java_final_pom.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CountUpProgressBarTest {

    @Test
    void updateUI() {
    }

    @Test
    void getUI() {
    }

    @Test
    void setUI() {
    }

    @Test
    void getUIClassID() {
    }

    @Test
    void paramString() {
    }

    @Test
    void getAccessibleContext() {
    }

    @Test
    void safelyGetGraphics() {
    }

    @Test
    void testSafelyGetGraphics() {
    }
}