package Java_final_pom.model;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void get_id() {
    }

    @org.junit.jupiter.api.Test
    void get_name() {
    }

    @org.junit.jupiter.api.Test
    void get_subjects() {
    }

    @org.junit.jupiter.api.Test
    void get_hours() {
    }

    @org.junit.jupiter.api.Test
    void setId() {
    }

    @org.junit.jupiter.api.Test
    void setSubjects() {
    }

    @org.junit.jupiter.api.Test
    void setName() {
    }
}