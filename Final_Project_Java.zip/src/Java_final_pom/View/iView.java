package Java_final_pom.View;

public interface iView {


}
