package Java_final_pom.model;
import Java_final_pom.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CountUpProgressBar extends JPanel {
    JLabel text;
    JProgressBar bar = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    JLabel label = new JLabel(" Ok Next Session", JLabel.CENTER);
    Timer timer = new Timer(100, new ActionListener() {
        int counter = 1;
        @Override
        public void actionPerformed(ActionEvent ae) {
            label.setText(String.valueOf(counter));
            bar.setValue(++counter);
            if (counter > 100) {
                timer.stop();
            }
        }
    });
    public CountUpProgressBar( JPanel e) {
        e.setLayout(new GridLayout(0, 1));
        bar.setValue(0);
        timer.start();
        e.add(bar);
        e.add(label);
        //JOptionPane.showMessageDialog(null, null);
       this.text = new JLabel("Cilck 'OK' on Popup Message or 'Save' To end session' ");
        label.setFont(new Font("Calibri", Font.CENTER_BASELINE, 14));
        label.setBounds(60,600,275,40);
        e.add(text);
    }
}
