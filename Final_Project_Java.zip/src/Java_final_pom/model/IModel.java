package Java_final_pom.model;

public interface IModel {
}
