package Java_final_pom.model;

public class Model {

}
