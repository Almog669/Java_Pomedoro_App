package Model_View;

public interface IModel_View {

}
