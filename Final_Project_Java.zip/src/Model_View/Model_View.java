package Model_View;
import Java_final_pom.View.View;
import Java_final_pom.model.User;
import java.util.ArrayList;

public class Model_View {
    User user;
    public  static void  main ( String argv[])
    {
        View one = new View();
        one.go();
    }

}
